/*
 * Archivo: Espectador.c
 * Proyecto: CRR - Batalla naval
 *
 * Fecha de creaci�n: 2-10-2011
 * 
 *
 * Nota: Definicion de las funciones de la clase Espectador
 *
 */
