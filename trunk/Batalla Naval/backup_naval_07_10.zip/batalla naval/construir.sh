make

rm *.o

./SSOO

