make

rm *.o
