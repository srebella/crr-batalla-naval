/*
 * conexion.c
 *
 *  Created on: 01/10/2011
 *      
 */

#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>


#include "funciones.h"
#include "fachada.h"
#include "buffer.h"

#define SERVER 2012
#define MAX_LINE 20
#define MAX_CONN 10

int main (int argc, char *argv[]){
	int conexion_socket, manejador_socket,flag,dt[2];
	int J1,J2;
	char buffer[MAX_LINE],buffer1[MAX_LINE],buffer2[MAX_LINE];
	pid_t idProceso;
	//obtiene datos del usuario
	flag=0;
	if (1<argc){
		if ( !strncmp(argv[1], "-s", 2) || !strncmp(argv[1], "-s", 2) ) {
			flag = 1;
		}
	}
	pipe(dt);
	if (flag==1){			// Server
		printf("Soy server\n");
		manejador_socket=crear_servidor("2025");

		printf("Forkeando el proceso\n");
		idProceso = fork();

		if (idProceso == 0 ){
			while(1){
				int cant=0;
				if ((cant=read (dt[0], buffer, MAX_LINE)) < 0){
					//printf("infinitooo aaaaaaaa xD");
				}else{
				if(cant>0){
					printf("H: esperando conexion...\n");
					conexion_socket = buscar_nuevas_conexiones(manejador_socket);
					printf("H: acepte conexion\n");
				}else{

				}
			}
			}
		}else{
			sleep (3);
			printf("P: esperando conexion J1...\n");
			J1 = buscar_nuevas_conexiones(manejador_socket);
			printf("P: esperando conexion J2...\n");
			J2 = buscar_nuevas_conexiones(manejador_socket);
			printf("P: todo listo, que empiece el juego!\n");

			// Ahora activo la bandera para que busque otras conexiones
			strcpy (buffer, "Hola");
			write (dt[1], buffer, strlen(buffer)+1);

			strcpy(buffer1,"nada");
			strcpy(buffer2,"nada");
			recibir_datos(J1, buffer1, MAX_LINE);
			recibir_datos(J2, buffer2, MAX_LINE);
			printf("P: recibi %s del J1\n",buffer1);
			printf("P: recibi %s del J2\n",buffer2);
			printf("P: envio %s a J1\n",buffer2);
			printf("P: envio %s a J2\n",buffer1);
			enviar_datos(J1, buffer2, strlen(buffer2));
			enviar_datos(J2, buffer1, strlen(buffer1));
			close(J1);
			close(J2);
			printf("P: cerre conexion\n");
		}
	}else{				// Cliente
		printf("Soy cliente\n");
		conexion_socket=conectar_servidor("127.0.0.1","2025");

		printf("Nombre: ");
		fgets(buffer, MAX_LINE, stdin);

		printf("Mandando \"%s\"...",buffer);

		enviar_datos(conexion_socket, buffer, strlen(buffer));
		printf("Enviado\n");

		recibir_datos(conexion_socket, buffer, MAX_LINE);
		printf("Conectado con \"%s\"\n",buffer);
	}
	return 0;
}
