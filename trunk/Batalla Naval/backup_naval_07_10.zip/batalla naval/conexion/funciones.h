/*
 * funciones.h
 *
 *  Created on: 01/10/2011
 *     
 */

#ifndef FUNCIONES_H_
#define FUNCIONES_H_

int crear_servidor (char* puerto);

int conectar_servidor (char* IP, char* puerto);

int buscar_nuevas_conexiones(int manejador);

int enviar_datos(int conn_s, const void *pbuffer, size_t n);

int recibir_datos (int conn_s, void *pbuffer, size_t maxlen);

#endif /* FUNCIONES_H_ */
