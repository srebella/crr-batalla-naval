/*
 * buffer.h
 *
 *  Created on: 01/10/2011
 *      
 */

#ifndef BUFFER_H_
#define BUFFER_H_



#endif /* BUFFER_H_ */
