/*
 * buffer.c
 *
 *  Created on: 01/10/2011
 *     
 */


